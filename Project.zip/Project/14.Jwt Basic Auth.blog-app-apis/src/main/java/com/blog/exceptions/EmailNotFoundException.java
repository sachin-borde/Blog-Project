package com.blog.exceptions;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmailNotFoundException extends RuntimeException {

	String resourcename;
	String fieldname;
	String fieldValue;

	public EmailNotFoundException(String resourcename, String fieldname, String fieldValue) {
		super(String.format("%s Not Found With %s : %s", resourcename, fieldname, fieldValue));
		this.resourcename = resourcename;
		this.fieldname = fieldname;
		this.fieldValue = fieldValue;
	}
}
